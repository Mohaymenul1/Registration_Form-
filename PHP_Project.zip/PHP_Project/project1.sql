-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 08:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Id` int(250) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Roll` int(100) NOT NULL,
  `Batch` varchar(100) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `Course` varchar(100) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Birthdate` date NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Id`, `Name`, `Address`, `Roll`, `Batch`, `Semester`, `Course`, `Gender`, `Birthdate`, `Email`, `Phone`) VALUES
(0, 'Shoron', 'Khandakerpara Sherpur Bogra', 903154, '15', '3', 'CSE', 'Male', '2024-05-10', 'testuser123@gmail.com', 1755555555),
(1, 'Emran', 'Bogua', 121232, '2nd', '3rd', 'CSE', 'Male', '2024-05-08', 'anamulhaqueshoron@gmail.com', 175565656);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Id` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Roll` int(100) NOT NULL,
  `Batch` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `Course` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` int(100) NOT NULL,
  `Birthdate` varchar(200) NOT NULL,
  `Color` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Id`, `Name`, `Roll`, `Batch`, `Semester`, `Course`, `Gender`, `Email`, `Phone`, `Birthdate`, `Color`, `Address`) VALUES
(1, 'test', 903154, '15', '1', 'CSE', 'Male', 'testuser123@gmail.com', 1755555555, '2024-05-21', '', 'Khandakerpara Sherpur Bogra'),
(2, 'Shoron', 903154, '15', '1', 'CSE', 'Male', 'testuser123@gmail.com', 1755555555, '2024-05-13', '', 'Khandakerpara Sherpur Bogra'),
(3, 'Asif', 903154, '15', '2', 'CSE', 'Male', 'testuser123@gmail.com', 1755555555, '2024-05-22', '', 'Khandakerpara Sherpur Bogra');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `Id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
