<?php
// Check if form is submitted
if(isset($_POST['name'])){
    // Retrieve form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $roll = $_POST['roll'];
    $batch = $_POST['batch'];
    $semester = $_POST['semester'];
    $course = $_POST['course'];
    $gender = $_POST['gender'];
    $birthdate = $_POST['birthdate'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    
    // Database connection
    $con = mysqli_connect('localhost', 'root', '', 'project1');
    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      exit();
    }
    
    // Insert data into database
    $sql = "INSERT INTO student (name, address, roll, batch, semester, course, gender, birthdate, email, phone) 
            VALUES ('$name', '$address', $roll, '$batch', '$semester', '$course', '$gender', '$birthdate', '$email', $phone)";
    $result = mysqli_query($con, $sql);
    if($result){
        header('Location: index.php');
        echo "Record added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
    
    // Close connection
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom Styles */
    body {
      background-color: #f8f9fa;
    }
    .contact-form {
      max-width: 500px;
      margin: 0 auto;
      padding: 30px;
      background-color: #fff;
      border-radius: 8px;
      margin-top: 50px;
      box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="contact-form">
          <h2 class="text-center">Registration Form</h2>
          <form method="POST">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" name="name" class="form-control" id="name" placeholder="Enter your name" required>
            </div>
            <div class="form-group">
              <label for="address">Address</label>
              <textarea class="form-control" name="address" id="address" rows="3" placeholder="Enter your address" required></textarea>
            </div>
            <div class="form-group">
              <label for="roll">Roll</label>
              <input type="number" name="roll" class="form-control" id="roll" placeholder="Enter your roll number" required>
            </div>
            <div class="form-group">
              <label for="batch">Batch</label>
              <select name="batch" class="form-control" id="batch" required>
                <option value="">Select Batch</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
              </select>
            </div>
            <div class="form-group">
              <label for="semester">Semester</label>
              <select name="semester" class="form-control" id="semester" required>
                <option value="">Select Semester</option>
                <?php for($i=1; $i<=8; $i++) { ?>
                  <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group">
              <label for="course">Course</label>
              <select name="course" class="form-control" id="course" required>
                <option value="">Select Course</option>
                <option value="CSE">CSE</option>
                <option value="CE">CE</option>
                <option value="EEE">EEE</option>
              </select>
            </div>
            <div class="form-group">
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="male" value="Male" required>
                <label class="form-check-label" for="male">Male</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="female" value="Female" required>
                <label class="form-check-label" for="female">Female</label>
              </div>
            </div>
            <div class="form-group">
              <label for="birthdate">Birthdate</label>
              <input name="birthdate" type="date" class="form-control" id="birthdate" required>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input name="email" type="email" class="form-control" id="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input name="phone" type="tel" class="form-control" id="phone" placeholder="Enter your phone number" pattern="[0-9]{11}" title="Please enter 11 digits" required>
            </div>
            <div class="form-group">
              <label for="image">Image</label>
              <input type="file" class="form-control-file" id="image">
            </div>
            <div class="form-group">
                <label for="Color">What is your favourite Color?</label>
                <select class="form-control" id="color">
                  <option value="">Select Color</option>
                  <option value="1">Red</option>
                  <option value="2">Green</option>
                  <option value="3">Blue</option>
                  <option value="4">Yellow</option>
                  <option value="5">Orange</option>
                </select>
            </div>
              <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="terms">
                <label class="form-check-label" for="terms">I accept the terms and conditions</label>
              </div>
              <div class="form-group">
                <label for="captcha">Captcha</label>
                <div class="input-group">
                  <div class="input-group-append">
                    <span class="input-group-text" id="captcha-question"></span>
                  </div>
                  <input type="text" class="form-control" id="captcha" placeholder="Enter the result" required>
                </div>
                <small class="form-text text-muted" id="captcha-instruction">Please solve the math problem.</small>
              </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS and dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    // Function to generate a random math problem
    function generateCaptcha() {
      var num1 = Math.floor(Math.random() * 10) + 1; // Generate a random number between 1 and 10
      var num2 = Math.floor(Math.random() * 10) + 1; // Generate a random number between 1 and 10
      var operation = ['+', '-', '*'][Math.floor(Math.random() * 3)]; // Choose a random operation
      var result;
      
      // Perform the operation
      switch (operation) {
        case '+':
          result = num1 + num2;
          break;
        case '-':
          result = num1 - num2;
          break;
        case '*':
          result = num1 * num2;
          break;
      }
      
      // Display the math problem
      document.getElementById('captcha-question').textContent = num1 + ' ' + operation + ' ' + num2 + ' =';
      // Store the correct result in a hidden input field
      document.getElementById('captcha-result').value = result;
    }

    // Generate the captcha when the page loads
    window.onload = function() {
      generateCaptcha();
    };
  </script>
</body>
</html>
