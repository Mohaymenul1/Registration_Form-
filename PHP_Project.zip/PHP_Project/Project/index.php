<?php
// Database connection
$con = mysqli_connect('localhost', 'root', '', 'project1');
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

// Fetching data from the database
$sql = "SELECT * FROM student";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom Styles */
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row clearfix">
      <div class="col-md-2">
            <br>
            <a href="insert.php" class="btn btn-success">Add Student</a>
       </div>
        <div class="col-md-8">
            <h1>Student List</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>Name</th>
                        <th>Roll</th>
                        <th>Course</th>
                        <th>Semester</th>
                        <th>Batch</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $counter = 1;
                        while($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo $counter++; ?></td>
                        <td><?php echo $row['Name']; ?></td>
                        <td><?php echo $row['Roll']; ?></td>
                        <td><?php echo $row['Course']; ?></td>
                        <td><?php echo $row['Semester']; ?></td>
                        <td><?php echo $row['Batch']; ?></td>
                        <td><?php echo $row['Email']; ?></td>
                        <td class="d-flex">
                            <a href="view.php?id=<?php echo $row['Id']; ?>" class="btn btn-info mr-1">View</a>
                            <a href="edit.php?id=<?php echo $row['Id']; ?>" class="btn btn-primary mr-1">Edit</a>
                            <a href="view.php" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
  </div>

  <!-- Bootstrap JS and dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
